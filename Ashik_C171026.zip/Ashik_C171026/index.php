<html>
    <head>
        <title>Brain Domination test</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            include 'php/declr.php';
            include 'php/init.php';
        
        ?>
        <div class="fix main">
            <div class="fix header">
                <div class="fix logo">Brain Domination Test</div>
               
            </div>
            <div class="fix sidemenu">
                <ul>
                    
                    <li><a href="">Home </a></li>
                    <li><a href="ques/1.php" target="frame">Retake</a></li>
                    
                   
                </ul>
            </div>
            <div class="fix bdy">
                <iframe src="other/Welcome.html" name="frame"></iframe>
            
            </div>
            <div class="fix footer">
                <div class="fix contacts">
                   <h2>Contacts</h2>
                    <hr style=" width:300px;" color="red" align:center;>
                </div>
                <div class="fix address" align="center">
                <p>
                    Mohammad Ashikul Islam<br>
                    habijabi@gmail.com<br>
                    Phone:018235432<br>
                </p>
                </div>
                <div class="fix other">
                    
                </div>
            
            </div>
            
            
        
        </div>
    
    </body>
</html>