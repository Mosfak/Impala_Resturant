<html>
<head>
    <link rel="stylesheet" type="text/css" href="welcome.css">
</head>
<body>
 
    
    <form action="../php/action.php" method="post">
        <h2>ques?</h2>
        <br>
          
        <input type="radio"  Value="Option1" name="ques">
        Option 1<br>
        
        <input type="radio"  Value="Option2" name="ques">
        Option 2<br>
        
        <input type="submit" name="submit" value="next" >
        
    
    </form>
   
 
</body>


</html>