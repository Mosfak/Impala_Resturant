<html>
<head>
<title>
Hall Booking System
</title>
<meta http-equiv="refresh" content="10; url=track.php">
</head>
<body>
<center>
<h1>Donz Hall Booking</h1>
<hr>
<p>
You have Cancel your paymeny<br>
Note: Do not refresh or close this page
</p>
Please wait a moment while your details is being clear.
Loading...
</center>
</body>
</html>
