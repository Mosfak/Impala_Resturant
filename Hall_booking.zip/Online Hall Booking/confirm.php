<html>
<head>
<title>
Hall Booking System
</title>
<meta http-equiv="refresh" content="10; url=schpayment.php">
</head>
<body>
<center>
<h1>Hall Booking System</h1>
<hr>
<p>
Your Will be redirect to payment<br>
Note: Do not refresh or close this page
</p>
Please wait...
</center>
</body>
</html>
