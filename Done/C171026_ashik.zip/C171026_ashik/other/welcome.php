<html>
<head>
    <link rel="stylesheet" type="text/css" href="welcome.css">
</head>
<body>
 
    <div class="wlcm">
        <h1>Welcome!!</h1>
        <a href="../ques/1.php" target="_self">Take the test</a>
    </div>
   
 
</body>


</html>