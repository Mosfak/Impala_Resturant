<html>
<head>
    <link rel="stylesheet" type="text/css" href="welcome.css">
</head>
<body>
 
    
    <form action="../php/action.php" method="post">
        <h2>Which one do you remember more easily:<br>
  The face or the name of someone you just met?</h2>
        <br>
          
        <input type="radio"  Value="Option1" name="ques">
        Face<br>
        
        <input type="radio"  Value="Option2" name="ques">
        Name<br>
        
        <input type="submit" name="submit" value="next" >
        
    
    </form>
   
 
</body>


</html>