<html>
<head>
    <link rel="stylesheet" type="text/css" href="welcome.css">
    
</head>
<body>
 
    
    <form action="../php/action.php" method="post">
        <h2>When you are reading a book or an article:</h2>
        <br>
          
        <input type="radio"  Value="Option1" name="ques">
        I prefer to skim through and focus on the most interesting parts<br>
        
        <input type="radio"  Value="Option2" name="ques">
        You pay attention on every word and every dtail<br>
        
        <input type="submit" name="submit" value="next" >
        
    
    </form>
   
 
</body>


</html>