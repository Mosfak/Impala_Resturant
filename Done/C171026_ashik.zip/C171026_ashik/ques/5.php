<html>
<head>
    <link rel="stylesheet" type="text/css" href="welcome.css">
    
</head>
<body>
    
    
    <form action="../php/action.php" method="post">
        <h2>When you listen to a new song,you emphasize more on_____</h2>
        <br>
          
        <input type="radio"  Value="Option1" name="ques">
        Music<br>
        
        <input type="radio"  Value="Option2" name="ques">
        Lyric<br>
        
        <input type="submit" name="submit" value="next" >
        
    
    </form>
   
 
</body>


</html>