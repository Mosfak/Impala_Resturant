<?php
    $_SESSION['left']=0;
    $_SESSION['right']=0;
    $_SESSION['pg']=1;
    $_SESSION['result']="Not Available";
    $_SESSION['leftScore']=0;
    $_SESSION['rightScore']=0;



?>