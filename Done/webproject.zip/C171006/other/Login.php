<html>
    <head>
        <link href="login.css" type="text/css" rel="stylesheet" >
    </head>
    <body>
        
        <div class="wrapper">
            <div class="frm" >
                
                <form action="../php/loginaction.php" method="post">
                    <center><h1><u>Login</u></h1></center>
                    <lebel for="email">Email:</lebel><br>
                    <input type="text" name="email" /><br>
                    <lebel for="pass">Password:</lebel><br>
                    <input type="password" name="pass" /><br>
                    <input type="submit" name="submit" value="submitted"><br>
                    <a href="SignUp.php"> >>SignUp</a>
                </form>

            </div>
        </div>
        
    </body>
</html>