<html>
    <head>
        <title>Impala Restaurant</title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/default/default.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="css/light/light.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="css/dark/dark.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="css/bar/bar.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
    </head>
    <body>
        <div class="fix main">
            
            <div class="fix header">
                <div class="fix logo"><h1><span style="color:yellow;font-size:50;text-decoration:;">Im<span style="color:blue;">pala</span></span><br>Restaurant</h1></div>
                <div class="fix menu">
                    <ul>
                        <li><a href="other/orderNow.php">Order Now</a></li>
                        <li><a href="#ftr">About Us</a></li>
                        <li><a href="other/orderNow.php">Menu</a></li>
                        <li><a href="#spofr">Special Offer</a></li>
                        <li><a href="other/login.php">Sign in</a></li>
                    </ul>
                </div>
            </div>
            <div class="fix slider">
                <div class="slider-wrapper theme-default" >
                    <div class="nivoslider" id="slider">
                        <a href=""><img src="img/1.jpg" title="#htmlCaption1"></a>
                        <a href=""><img src="img/2.jpg" title="#htmlCaption2"></a>
                        <a href=""><img src="img/3.jpg" title="#htmlCaption3"></a>
                        <a href=""><img src="img/4.jpg" title="#htmlCaption4"></a>
                        <a href=""><img src="img/5.jpg" title="#htmlCaption5"></a>
                        <a href=""><img src="img/6.jpg" title="#htmlCaption6"></a>
                        <a href=""><img src="img/7.jpg" title="#htmlCaption7"></a>
                    </div>
                </div>
                <div id="htmlCaption1" class="nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>
                <div id="htmlCaption2" class="nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>
                <div id="htmlCaption3" class="nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>
                <div id="htmlCaption4" class="nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>
                <div id="htmlCaption5" class="nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>
                <div id="htmlCaption6" class="nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>
                <div id="htmlCaption7" class="htmlcaption nivo-html-caption"><h2>Special Fest Offers!</h2><br><h1>Order Now</h1><br><p>Lorum Ipsum tasty ipsum.</p>
                </div>   
            </div>
            <hr>
            <div id="spofr" class="fix menuitem">
                <div class="container">
                    <div class="item item1"></div>
                    <div class="item item2"></div>
                    <div class="item item3"></div>
                    <div class="item item4"></div>
                    <div class="item item5"></div>
                    <div class="item item6"></div>
                </div>
            </div>
            <hr color="red" height="5px;" style="margin-bottom:20px;">
            <div class="fix kitchen">
                <div class="text">
                    <h1>Our Kitchen</h1><br>
                    <p>
                    The kitchen is fitted with the most up<br>
                    to date hygienic kitchen maintained and<br>
                    operated by our highly trained team of <br>
                    Food and Beverage specialists. Our service<br>
                    staff are professionally trained and <br>
                    knowledgeable in the local area and <br>
                    aim to assist in making your stay <br>
                    pleasurable and an unforgettable <br>
                    experience</p>
                </div>
            </div>
            <div class="fix interior">
                <div class="fix text">
                    <h1>Our Interior</h1><br>
                    <p>
                    The interior is fitted with the most up<br>
                    to date hygienic, maintained and<br>
                    operated by our highly trained team of <br>
                    Food and Beverage specialists. Our service<br>
                    staff are professionally trained and <br>
                    knowledgeable in the local area and <br>
                    aim to assist in making your stay <br>
                    pleasurable and an unforgettable <br></p>
                </div>
                <div class="fix image">
                    <img src="img/interior.jpg">
                </div>
            </div>
            <div class="fix about"></div>
            <div id="ftr" class="fix footer" >
                <div class="fix contacts">
                    <h1>Contacts</h1>
                    <hr width="300px"  color="red" style="margin-left: 600px;">
                    <p >Email:mosfak2400@gmail.com</p>
                    <p>Phone:01590127784</p>
                </div>
                <div class="fix seat">
                    <form>
                        <h2>Reserve a Seat!</h2>
                        Enter date:<br>
                        <input type="date"><br>
                        Enter Time:<br>
                        <input type="time"><br>
                        Enter party size:<br>
                        <input type="number"><br>
                        <input type="text" placeholder="Enter Your Email"><br>
                        <input type="submit" onclick="alert('Your Reservarion is being processed \nWe will inform you through a mail')"><br>
                    </form>
                </div>
                <div class="fix social">
                    <h2>We are Open<br>7.00AM-9.00PM</h2>
                </div>
                <div class="fix map">
                    <h3>We are Here:</h3>
                    <img src="img/map.png" width="400" height="200">
                </div>
            </div>
			<div class="fix cpyright">
				<hr color="white">
				&copy;Developed by Mosfak Motin Rimon
			</div>
			
			
			
            
        
        
        </div>
        <!-- Java Script Starts -->
        <script src="js/jquery-1.7.1.min.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 
        <script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script> 
        <script type="text/javascript">
            $(window).load(function() {
                $('#slider').nivoSlider();
            });
        </script> 
        
        
    </body>
</html>