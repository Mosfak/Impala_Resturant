<html>
<head>
<title>About ME</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="Assets/css/style.css" rel="stylesheet" />
<link href="Assets/css/menu.css" rel="stylesheet" />
<style>
.im
{
	border:double #01c001;
	border-radius:200px;
}
</style>
</head>
<body>
<header>
  <?php include("include/header.php");?>
</header>
<?php include("include/menu.php");?>
<section> 
<div class="sec2">
<div class="container">
  <center>
  <h2><u>About Me</u></h2>
 <p>Hi, My name is Sultan MAhmud<br>
 Phone: 01521401626<br>
 
 <br>
 <img src="Assets/images/picture/owner.jpg" width="200" class="im">
 </p>
  <br>
  <p>
  <h3>Follow me on social media</h3>
  <br>
   <a href=""><img src="Assets/images/social/facebook.png" width="100" title="Facebook"></a>
    <a href=""><img src="Assets/images/social/instagram.png" width="100" title="Instagram"></a>
	<a href=""><img src="Assets/images/social/twitter.png" width="100" title="Twitter"></a>
  </p>
  </center>
</div>
</div>
</section>
<?php include("include/footer.php");?>
</body>
</html>
