<footer>
<center>
  <p>Design and Developed by Sultan Mahmud<br>
  <h4>Contact Me</h4><a href="contact.php">Click Here</a>
  </p>
  </center>
</footer>
