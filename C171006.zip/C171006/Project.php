<html><head><title>Burger Zone</title>
<style>
.links
{
border-radius:10px;
}
.links:hover
{
background-color:green;
}

.zoom
{
transition:transform 0.5s;
}
.zoom:hover
{
transform:scale(1.2);
    }
</style>
</head>

<body>
<table border="0" width="100%" height="10%">
<tr>
    <td width="12.5%" align="center" bgcolor="purple" class="links"><font color="white"><a href="Project.php">HOME</a></td>
<td width="12.5%" align="center" bgcolor="purple" class="links"><font color="white">ABOUT US</td>
<td width="12.5%" align="center" bgcolor="purple" class="links"><font color="white">CONTACT US</td>
<td width="12.5%" align="center" bgcolor="purple" class="links"><font color="white">MENU</td>
<td width="12.5%" align="center" bgcolor="purple" class="links"><font color="white">VARIETIES</td>
<td width="12.5%" align="center" bgcolor="purple" class="links"><font color="white">FEEDBACK</td>
<td width="12.5%" align="center" bgcolor="purple" class="links" onclick="location.href='other/SignUP.php'"><font color="white" >SIGN UP</td>
    
<td width="12.5%" align="center" bgcolor="purple" class="links" onclick="location.href='other/Login.php'"><font color="white" >LOGIN</td>
</tr>
</table>

<img src="Theme.jpg" width="100%" height="85%">

<table border="0" width="100%">
<tr>
<td class="zoom" align="center"><img src="1.jpg" height="23%"></td>
<td class="zoom" align="center"><img src="2.jpg" height="38%"></td>
<td class="zoom" align="center"><img src="3.jpg" height="25%"></td>
<td class="zoom" align="center"><img src="4.jpg" height="32%"></td>
</tr>

<tr>
<td class="zoom" align="center"><img src="5.jpg" height="32%"></td>
<td class="zoom" align="center"><img src="6.jpg" height="38%"></td>
<td class="zoom" align="center"><img src="7.jpg" height="28%"></td>
<td class="zoom" align="center"><img src="8.jpg" height="28%"></td>
</tr>
</table>

<table border="3" width="100%" bgcolor="purple" height="10%">
<tr>
<td align="center"><font color="white">Designed By - Burger Zone</td>
</tr>
</table>
