<!DOCTYPE html>
<html>
<head>
      <title> Hotel Shotoshopa</title>
	  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
     <header id="hm">		 
         <div class=" logo">
             <img src ="logo.png">
			
		 <ul>
		     <li><a href=""><b>HOME</b></a></li>
			 <li><a href="gallery.php"><b>Gallery</b></a></li>
			 <li><a href="#room"><b>Room</b></a></li>
			 <li><a href="#about"><b>About</b></a></li>
			 <li><a href="Contact.php"><b>Contact</b></a></li>
             <li><a href="other/Login.php"><b>Log in</b></a></li>
		 </ul>
         </div>
         <div class ="title">
		        <h1> Welcome</h1>
				
         </div>
         
    </header >
    
    </body>
</html>
